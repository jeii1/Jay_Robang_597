package com.example.casestudy08

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
