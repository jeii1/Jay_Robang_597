import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ClericalDashboard extends StatefulWidget {
  const ClericalDashboard({super.key});

  @override
  State<ClericalDashboard> createState() => _ClericalDashboardState();
}

class _ClericalDashboardState extends State<ClericalDashboard> {
  final _supabase = Supabase.instance.client;
  int _selectedIndex = 0;

  List<Map<String, dynamic>> _members = [];
  bool _loading = true;

  // Report form controllers
  final _reportTitleController = TextEditingController();
  final _reportContentController = TextEditingController();
  bool _submittingReport = false;

  // Edit member dialog
  final _editNameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadMembers();
  }

  @override
  void dispose() {
    _reportTitleController.dispose();
    _reportContentController.dispose();
    _editNameController.dispose();
    super.dispose();
  }

  Future<void> _loadMembers() async {
    setState(() => _loading = true);
    try {
      final res = await _supabase
          .from('members')
          .select('*, users:user_id(email)')
          .order('created_at', ascending: false);
      setState(() {
        _members = List<Map<String, dynamic>>.from(res);
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      _showError('Error loading members: $e');
    }
  }

  Future<void> _submitReport() async {
    if (_reportTitleController.text.trim().isEmpty ||
        _reportContentController.text.trim().isEmpty) {
      _showError('Please fill in all report fields.');
      return;
    }
    setState(() => _submittingReport = true);
    try {
      await _supabase.from('reports').insert({
        'title': _reportTitleController.text.trim(),
        'content': _reportContentController.text.trim(),
        'submitted_by': _supabase.auth.currentUser?.id,
        'role': 'clerical',
        'status': 'submitted',
      });
      _reportTitleController.clear();
      _reportContentController.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Report submitted to manager!'),
              backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      _showError('Failed to submit report: $e');
    } finally {
      setState(() => _submittingReport = false);
    }
  }

  Future<void> _updateMember(String memberId, String newName) async {
    try {
      await _supabase
          .from('members')
          .update({'full_name': newName}).eq('id', memberId);
      await _loadMembers();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Member info updated!'),
              backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      _showError('Update failed: $e');
    }
  }

  void _showEditDialog(Map<String, dynamic> member) {
    _editNameController.text = member['full_name'] ?? '';
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Update Member Info'),
        content: TextField(
          controller: _editNameController,
          decoration: const InputDecoration(
              labelText: 'Full Name', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00897B)),
            onPressed: () {
              Navigator.pop(ctx);
              _updateMember(member['id'], _editNameController.text.trim());
            },
            child: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showError(String msg) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: Colors.red),
      );
    }
  }

  void _logout() async {
    await _supabase.auth.signOut();
    if (mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFF00897B),
        title: const Text('PQR Cooperative – Clerical',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: _loadMembers),
          IconButton(
              icon: const Icon(Icons.logout, color: Colors.white),
              onPressed: _logout,
              tooltip: 'Logout'),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF00897B)))
          : Column(
              children: [
                _buildNavTabs(),
                Expanded(child: _buildTabContent()),
              ],
            ),
    );
  }

  Widget _buildNavTabs() {
    final tabs = [
      {'icon': Icons.people_outline, 'label': 'New Members'},
      {'icon': Icons.edit_note_outlined, 'label': 'Update Info'},
      {'icon': Icons.summarize_outlined, 'label': 'Reports'},
    ];
    return Container(
      color: Colors.white,
      child: Row(
        children: List.generate(tabs.length, (i) {
          final selected = _selectedIndex == i;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedIndex = i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: selected
                          ? const Color(0xFF00897B)
                          : Colors.transparent,
                      width: 3,
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    Icon(tabs[i]['icon'] as IconData,
                        color: selected ? const Color(0xFF00897B) : Colors.grey,
                        size: 22),
                    const SizedBox(height: 4),
                    Text(
                      tabs[i]['label'] as String,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight:
                            selected ? FontWeight.bold : FontWeight.normal,
                        color: selected ? const Color(0xFF00897B) : Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_selectedIndex) {
      case 0:
        return _buildNewMembers();
      case 1:
        return _buildUpdateMembers();
      case 2:
        return _buildReports();
      default:
        return const SizedBox();
    }
  }

  Widget _buildNewMembers() {
    // Show members sorted by newest first
    if (_members.isEmpty) {
      return _emptyState(Icons.person_add_alt_1_outlined, 'No members yet',
          'Newly registered members will appear here.');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _members.length,
      itemBuilder: (context, i) {
        final m = _members[i];
        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: CircleAvatar(
              backgroundColor: const Color(0xFF00897B).withOpacity(0.15),
              child: Text(
                (m['full_name'] ?? 'M')[0].toUpperCase(),
                style: const TextStyle(
                    color: Color(0xFF00897B), fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(m['full_name'] ?? 'Unknown',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(m['users']?['email'] ?? '-',
                    style: const TextStyle(fontSize: 12)),
                Text('Joined: ${_formatDate(m['created_at'])}',
                    style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
            trailing: Chip(
              label: const Text('Member', style: TextStyle(fontSize: 11)),
              backgroundColor: Colors.blue.shade50,
              side: BorderSide(color: Colors.blue.shade200),
            ),
          ),
        );
      },
    );
  }

  Widget _buildUpdateMembers() {
    if (_members.isEmpty) {
      return _emptyState(
          Icons.edit_off_outlined, 'No members', 'No members to update.');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _members.length,
      itemBuilder: (context, i) {
        final m = _members[i];
        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: CircleAvatar(
              backgroundColor: Colors.orange.shade50,
              child: Icon(Icons.person, color: Colors.orange.shade700),
            ),
            title: Text(m['full_name'] ?? 'Unknown',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(m['users']?['email'] ?? '-',
                style: const TextStyle(fontSize: 12)),
            trailing: ElevatedButton.icon(
              icon: const Icon(Icons.edit, size: 16),
              label: const Text('Edit', style: TextStyle(fontSize: 13)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00897B),
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
              onPressed: () => _showEditDialog(m),
            ),
          ),
        );
      },
    );
  }

  Widget _buildReports() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Icon(Icons.summarize_outlined, color: Color(0xFF00897B)),
                const SizedBox(width: 8),
                const Text('Submit Report to Manager',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF00897B))),
              ]),
              const Divider(height: 24),
              TextField(
                controller: _reportTitleController,
                decoration: InputDecoration(
                  labelText: 'Report Title',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                  prefixIcon: const Icon(Icons.title),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _reportContentController,
                maxLines: 7,
                decoration: InputDecoration(
                  labelText: 'Report Content',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                  prefixIcon: const Padding(
                    padding: EdgeInsets.only(bottom: 90),
                    child: Icon(Icons.description_outlined),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: _submittingReport
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.send_outlined),
                  label: Text(
                      _submittingReport ? 'Submitting...' : 'Submit Report'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00897B),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: _submittingReport ? null : _submitReport,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _emptyState(IconData icon, String title, String subtitle) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 64, color: Colors.grey.shade300),
        const SizedBox(height: 16),
        Text(title,
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey)),
        const SizedBox(height: 6),
        Text(subtitle,
            style: const TextStyle(fontSize: 13, color: Colors.grey)),
      ]),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return '-';
    try {
      final d = DateTime.parse(date.toString()).toLocal();
      return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    } catch (_) {
      return date.toString();
    }
  }
}
