import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MemberDashboard extends StatefulWidget {
  const MemberDashboard({super.key});

  @override
  State<MemberDashboard> createState() => _MemberDashboardState();
}

class _MemberDashboardState extends State<MemberDashboard> {
  final _supabase = Supabase.instance.client;
  int _selectedIndex = 0;

  Map<String, dynamic>? _memberInfo;
  List<Map<String, dynamic>> _loans = [];
  List<Map<String, dynamic>> _transactions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) return;

      final memberRes = await _supabase
          .from('members')
          .select()
          .eq('user_id', userId)
          .maybeSingle();

      List<Map<String, dynamic>> loans = [];
      List<Map<String, dynamic>> transactions = [];

      if (memberRes != null) {
        final memberId = memberRes['id'];

        final loansRes = await _supabase
            .from('loans')
            .select()
            .eq('member_id', memberId)
            .order('created_at', ascending: false);

        final txRes = await _supabase
            .from('transactions')
            .select()
            .eq('member_id', memberId)
            .order('created_at', ascending: false);

        loans = List<Map<String, dynamic>>.from(loansRes);
        transactions = List<Map<String, dynamic>>.from(txRes);
      }

      setState(() {
        _memberInfo = memberRes;
        _loans = loans;
        _transactions = transactions;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error loading data: $e'),
              backgroundColor: Colors.red),
        );
      }
    }
  }

  void _logout() async {
    await _supabase.auth.signOut();
    if (mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0),
        title: const Text('PQR Cooperative',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadData,
            tooltip: 'Refresh',
          ),
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: _logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF1565C0)))
          : Column(
              children: [
                _buildWelcomeBanner(),
                _buildNavTabs(),
                Expanded(child: _buildTabContent()),
              ],
            ),
    );
  }

  Widget _buildWelcomeBanner() {
    final name = _memberInfo?['full_name'] ??
        _supabase.auth.currentUser?.email ??
        'Member';
    final balance = _memberInfo?['balance'] ?? 0.0;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1565C0), Color(0xFF42A5F5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Row(
        children: [
          const CircleAvatar(
            radius: 26,
            backgroundColor: Colors.white24,
            child: Icon(Icons.person, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Welcome back,',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                Text(name,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text('Balance',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
              Text(
                '₱${(balance is num ? balance : 0.0).toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNavTabs() {
    final tabs = [
      {'icon': Icons.account_circle_outlined, 'label': 'Account'},
      {'icon': Icons.credit_card_outlined, 'label': 'Loans'},
      {'icon': Icons.history, 'label': 'History'},
    ];
    return Container(
      color: Colors.white,
      child: Row(
        children: List.generate(tabs.length, (i) {
          final selected = _selectedIndex == i;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedIndex = i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: selected
                          ? const Color(0xFF1565C0)
                          : Colors.transparent,
                      width: 3,
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    Icon(tabs[i]['icon'] as IconData,
                        color: selected ? const Color(0xFF1565C0) : Colors.grey,
                        size: 22),
                    const SizedBox(height: 4),
                    Text(
                      tabs[i]['label'] as String,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight:
                            selected ? FontWeight.bold : FontWeight.normal,
                        color: selected ? const Color(0xFF1565C0) : Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_selectedIndex) {
      case 0:
        return _buildAccountInfo();
      case 1:
        return _buildLoans();
      case 2:
        return _buildPaymentHistory();
      default:
        return const SizedBox();
    }
  }

  Widget _buildAccountInfo() {
    if (_memberInfo == null) {
      return const Center(child: Text('No account information found.'));
    }
    final info = _memberInfo!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _infoCard('Account Details', Icons.badge_outlined, [
            _infoRow('Member ID', info['id']?.toString() ?? '-'),
            _infoRow('Full Name', info['full_name'] ?? '-'),
            _infoRow('Email', _supabase.auth.currentUser?.email ?? '-'),
            _infoRow('Member Since', _formatDate(info['created_at'])),
          ]),
          const SizedBox(height: 12),
          _infoCard(
              'Financial Summary', Icons.account_balance_wallet_outlined, [
            _infoRow('Savings Balance',
                '₱${(info['balance'] ?? 0.0).toStringAsFixed(2)}'),
            _infoRow('Active Loans',
                _loans.where((l) => l['status'] == 'active').length.toString()),
            _infoRow('Total Loans', _loans.length.toString()),
          ]),
        ],
      ),
    );
  }

  Widget _buildLoans() {
    if (_loans.isEmpty) {
      return _emptyState(Icons.credit_card_off_outlined, 'No loans found',
          'You have no loan records yet.');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _loans.length,
      itemBuilder: (context, i) {
        final loan = _loans[i];
        final status = loan['status'] ?? 'unknown';
        final statusColor = status == 'active'
            ? Colors.green
            : status == 'pending'
                ? Colors.orange
                : Colors.grey;
        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                        'Loan #${loan['id']?.toString().substring(0, 8) ?? '-'}',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 15)),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: statusColor),
                      ),
                      child: Text(status.toUpperCase(),
                          style: TextStyle(
                              color: statusColor,
                              fontSize: 11,
                              fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                const Divider(height: 16),
                _infoRow(
                    'Amount', '₱${(loan['amount'] ?? 0.0).toStringAsFixed(2)}'),
                _infoRow('Balance Due',
                    '₱${(loan['balance_due'] ?? 0.0).toStringAsFixed(2)}'),
                _infoRow('Applied', _formatDate(loan['created_at'])),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPaymentHistory() {
    if (_transactions.isEmpty) {
      return _emptyState(Icons.history_toggle_off_outlined, 'No transactions',
          'No payment history available.');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _transactions.length,
      itemBuilder: (context, i) {
        final tx = _transactions[i];
        final type = tx['type'] ?? 'transaction';
        final isCredit = type == 'deposit' || type == 'loan_release';
        return Card(
          elevation: 1,
          margin: const EdgeInsets.only(bottom: 10),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor:
                  isCredit ? Colors.green.shade50 : Colors.red.shade50,
              child: Icon(
                isCredit ? Icons.arrow_downward : Icons.arrow_upward,
                color: isCredit ? Colors.green : Colors.red,
                size: 20,
              ),
            ),
            title: Text(_capitalize(type.replaceAll('_', ' ')),
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            subtitle: Text(_formatDate(tx['created_at']),
                style: const TextStyle(fontSize: 12)),
            trailing: Text(
              '${isCredit ? '+' : '-'}₱${(tx['amount'] ?? 0.0).toStringAsFixed(2)}',
              style: TextStyle(
                color: isCredit ? Colors.green : Colors.red,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _infoCard(String title, IconData icon, List<Widget> children) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, color: const Color(0xFF1565C0), size: 20),
              const SizedBox(width: 8),
              Text(title,
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1565C0))),
            ]),
            const Divider(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
              width: 130,
              child: Text(label,
                  style: const TextStyle(color: Colors.grey, fontSize: 13))),
          Expanded(
              child: Text(value,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 13))),
        ],
      ),
    );
  }

  Widget _emptyState(IconData icon, String title, String subtitle) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 64, color: Colors.grey.shade300),
        const SizedBox(height: 16),
        Text(title,
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey)),
        const SizedBox(height: 6),
        Text(subtitle,
            style: const TextStyle(fontSize: 13, color: Colors.grey)),
      ]),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return '-';
    try {
      final d = DateTime.parse(date.toString()).toLocal();
      return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    } catch (_) {
      return date.toString();
    }
  }

  String _capitalize(String s) =>
      s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
}
