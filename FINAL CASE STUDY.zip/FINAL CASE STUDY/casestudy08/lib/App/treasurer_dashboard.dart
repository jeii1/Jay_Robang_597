import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class TreasurerDashboard extends StatefulWidget {
  const TreasurerDashboard({super.key});

  @override
  State<TreasurerDashboard> createState() => _TreasurerDashboardState();
}

class _TreasurerDashboardState extends State<TreasurerDashboard> {
  final _supabase = Supabase.instance.client;
  int _selectedIndex = 0;

  List<Map<String, dynamic>> _deposits = [];
  List<Map<String, dynamic>> _loanPayments = [];
  List<Map<String, dynamic>> _withdrawals = [];
  bool _loading = true;

  double get _totalDeposits =>
      _deposits.fold(0.0, (sum, t) => sum + (t['amount'] as num? ?? 0));
  double get _totalPayments =>
      _loanPayments.fold(0.0, (sum, t) => sum + (t['amount'] as num? ?? 0));
  double get _totalWithdrawals =>
      _withdrawals.fold(0.0, (sum, t) => sum + (t['amount'] as num? ?? 0));

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final depositsRes = await _supabase
          .from('transactions')
          .select('*, members(full_name)')
          .eq('type', 'deposit')
          .order('created_at', ascending: false);

      final paymentsRes = await _supabase
          .from('transactions')
          .select('*, members(full_name)')
          .eq('type', 'loan_payment')
          .order('created_at', ascending: false);

      final withdrawalsRes = await _supabase
          .from('transactions')
          .select('*, members(full_name)')
          .inFilter('type', ['withdrawal', 'refund']).order('created_at',
              ascending: false);

      setState(() {
        _deposits = List<Map<String, dynamic>>.from(depositsRes);
        _loanPayments = List<Map<String, dynamic>>.from(paymentsRes);
        _withdrawals = List<Map<String, dynamic>>.from(withdrawalsRes);
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error loading data: $e'),
              backgroundColor: Colors.red),
        );
      }
    }
  }

  void _logout() async {
    await _supabase.auth.signOut();
    if (mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFF6A1B9A),
        title: const Text('PQR Cooperative – Treasurer',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: _loadData),
          IconButton(
              icon: const Icon(Icons.logout, color: Colors.white),
              onPressed: _logout,
              tooltip: 'Logout'),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF6A1B9A)))
          : Column(
              children: [
                _buildSummaryBar(),
                _buildNavTabs(),
                Expanded(child: _buildTabContent()),
              ],
            ),
    );
  }

  Widget _buildSummaryBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF6A1B9A), Color(0xFFAB47BC)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Row(
        children: [
          _summaryChip('Deposits', '₱${_totalDeposits.toStringAsFixed(0)}',
              Icons.arrow_downward, Colors.green.shade200),
          _summaryChip('Payments', '₱${_totalPayments.toStringAsFixed(0)}',
              Icons.check_circle_outline, Colors.blue.shade200),
          _summaryChip(
              'Withdrawals',
              '₱${_totalWithdrawals.toStringAsFixed(0)}',
              Icons.arrow_upward,
              Colors.orange.shade200),
        ],
      ),
    );
  }

  Widget _summaryChip(
      String label, String value, IconData icon, Color iconColor) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            Icon(icon, color: iconColor, size: 18),
            const SizedBox(height: 4),
            Text(value,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 13)),
            Text(label,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.8), fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Widget _buildNavTabs() {
    final tabs = [
      {'icon': Icons.savings_outlined, 'label': 'Deposits'},
      {'icon': Icons.payments_outlined, 'label': 'Payments'},
      {'icon': Icons.money_off_outlined, 'label': 'Withdrawals'},
    ];
    return Container(
      color: Colors.white,
      child: Row(
        children: List.generate(tabs.length, (i) {
          final selected = _selectedIndex == i;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedIndex = i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: selected
                          ? const Color(0xFF6A1B9A)
                          : Colors.transparent,
                      width: 3,
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    Icon(tabs[i]['icon'] as IconData,
                        color: selected ? const Color(0xFF6A1B9A) : Colors.grey,
                        size: 22),
                    const SizedBox(height: 4),
                    Text(
                      tabs[i]['label'] as String,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight:
                            selected ? FontWeight.bold : FontWeight.normal,
                        color: selected ? const Color(0xFF6A1B9A) : Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_selectedIndex) {
      case 0:
        return _buildTransactionList(_deposits, 'No deposits recorded.',
            Colors.green, Icons.arrow_downward);
      case 1:
        return _buildTransactionList(
            _loanPayments,
            'No loan payments recorded.',
            Colors.blue,
            Icons.check_circle_outline);
      case 2:
        return _buildTransactionList(
            _withdrawals,
            'No withdrawals or refunds recorded.',
            Colors.orange,
            Icons.arrow_upward);
      default:
        return const SizedBox();
    }
  }

  Widget _buildTransactionList(
    List<Map<String, dynamic>> list,
    String emptyMsg,
    Color color,
    IconData icon,
  ) {
    if (list.isEmpty) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text(emptyMsg,
              style: const TextStyle(color: Colors.grey, fontSize: 15)),
        ]),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final tx = list[i];
        final memberName = tx['members']?['full_name'] ?? 'Unknown';
        final amount = (tx['amount'] as num? ?? 0).toDouble();
        final type = tx['type'] ?? '';
        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: color.withOpacity(0.1),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(memberName,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Text(_formatDate(tx['created_at']),
                          style: const TextStyle(
                              fontSize: 12, color: Colors.grey)),
                      if (type.isNotEmpty)
                        Text(_capitalize(type.replaceAll('_', ' ')),
                            style: TextStyle(
                                fontSize: 11,
                                color: color,
                                fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
                Text(
                  '₱${amount.toStringAsFixed(2)}',
                  style: TextStyle(
                      color: color, fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return '-';
    try {
      final d = DateTime.parse(date.toString()).toLocal();
      return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    } catch (_) {
      return date.toString();
    }
  }

  String _capitalize(String s) =>
      s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
}
