import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthProvider extends ChangeNotifier {
  final SupabaseClient _supabase = Supabase.instance.client;
  Map<String, dynamic>? _profile;
  bool _loading = false;

  Map<String, dynamic>? get profile => _profile;
  bool get loading => _loading;
  User? get currentUser => _supabase.auth.currentUser;
  bool get isLoggedIn => currentUser != null;
  String? get role => _profile?['role'];

  AuthProvider() {
    _supabase.auth.onAuthStateChange.listen((data) {
      final event = data.event;
      if (event == AuthChangeEvent.signedIn) {
        fetchProfile();
      } else if (event == AuthChangeEvent.signedOut) {
        _profile = null;
        notifyListeners();
      }
    });
    if (currentUser != null) fetchProfile();
  }

  Future<void> fetchProfile() async {
    if (currentUser == null) return;
    try {
      final data = await _supabase
          .from('profiles')
          .select()
          .eq('id', currentUser!.id)
          .single();
      _profile = data;
      notifyListeners();
    } catch (e) {
      throw Exception('Could not load user profile. Make sure your account has a role assigned.');
    }
  }

  Future<String?> signUp({
    required String email,
    required String password,
    required String fullName,
    required String role,
    String? phone,
    String? address,
  }) async {
    _loading = true;
    notifyListeners();
    try {
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
      );
      if (response.user != null) {
        await _supabase.from('profiles').insert({
          'id': response.user!.id,
          'full_name': fullName,
          'email': email,
          'role': role,
          'phone': phone,
          'address': address,
        });
        await fetchProfile();
      }
      return null;
    } on AuthException catch (e) {
      return e.message;
    } catch (e) {
      return 'An unexpected error occurred.';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<String?> signIn({
    required String email,
    required String password,
  }) async {
    _loading = true;
    notifyListeners();
    try {
      await _supabase.auth.signInWithPassword(email: email, password: password);
      await fetchProfile();
      return null;
    } on AuthException catch (e) {
      return e.message;
    } catch (e) {
      return 'An unexpected error occurred.';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    await _supabase.auth.signOut();
    _profile = null;
    notifyListeners();
  }
}