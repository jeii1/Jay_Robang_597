import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:pqr_cooperative/App/login_page.dart';
import 'package:pqr_cooperative/App/register_page.dart';
import 'package:pqr_cooperative/App/auth_provider.dart';
import 'package:pqr_cooperative/App/member_dashboard.dart';
import 'package:pqr_cooperative/App/clerical_dashboard.dart';
import 'package:pqr_cooperative/App/treasurer_dashboard.dart';
import 'package:pqr_cooperative/App/manager_dashboard.dart';

class AppRouter {
  static GoRouter router(AuthProvider authProvider) {
    return GoRouter(
      initialLocation: '/login',
      refreshListenable: authProvider,
      redirect: (context, state) {
        final isLoggedIn = authProvider.isLoggedIn;
        final isAuthRoute = state.matchedLocation == '/login' ||
            state.matchedLocation == '/register';

        if (!isLoggedIn && !isAuthRoute) return '/login';
        if (isLoggedIn && isAuthRoute) {
          return _getDashboardRoute(authProvider.role);
        }
        return null;
      },
      routes: [
        GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
        GoRoute(path: '/register', builder: (_, __) => const RegisterPage()),
        GoRoute(path: '/member', builder: (_, __) => const MemberDashboard()),
        GoRoute(
            path: '/clerical', builder: (_, __) => const ClericalDashboard()),
        GoRoute(
            path: '/treasurer', builder: (_, __) => const TreasurerDashboard()),
        GoRoute(path: '/manager', builder: (_, __) => const ManagerDashboard()),
      ],
    );
  }

  static String _getDashboardRoute(String? role) {
    switch (role) {
      case 'member':
        return '/member';
      case 'clerical_staff':
        return '/clerical';
      case 'treasurer':
        return '/treasurer';
      case 'manager':
        return '/manager';
      default:
        return '/login';
    }
  }
}
