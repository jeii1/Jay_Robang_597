import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ManagerDashboard extends StatefulWidget {
  const ManagerDashboard({super.key});

  @override
  State<ManagerDashboard> createState() => _ManagerDashboardState();
}

class _ManagerDashboardState extends State<ManagerDashboard> {
  final _supabase = Supabase.instance.client;
  int _selectedIndex = 0;

  List<Map<String, dynamic>> _reports = [];
  List<Map<String, dynamic>> _loans = [];
  List<Map<String, dynamic>> _members = [];
  bool _loading = true;

  // Stats
  int get _pendingLoans => _loans.where((l) => l['status'] == 'pending').length;
  int get _activeLoans => _loans.where((l) => l['status'] == 'active').length;
  int get _totalMembers => _members.length;
  int get _unreadReports =>
      _reports.where((r) => r['status'] == 'submitted').length;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final reportsRes = await _supabase
          .from('reports')
          .select()
          .order('created_at', ascending: false);

      final loansRes = await _supabase
          .from('loans')
          .select('*, members(full_name)')
          .order('created_at', ascending: false);

      final membersRes = await _supabase
          .from('members')
          .select('*, users:user_id(email)')
          .order('created_at', ascending: false);

      setState(() {
        _reports = List<Map<String, dynamic>>.from(reportsRes);
        _loans = List<Map<String, dynamic>>.from(loansRes);
        _members = List<Map<String, dynamic>>.from(membersRes);
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _updateLoanStatus(String loanId, String newStatus) async {
    try {
      await _supabase
          .from('loans')
          .update({'status': newStatus}).eq('id', loanId);
      await _loadData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Loan marked as $newStatus.'),
              backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Update failed: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _markReportRead(String reportId) async {
    try {
      await _supabase
          .from('reports')
          .update({'status': 'reviewed'}).eq('id', reportId);
      await _loadData();
    } catch (_) {}
  }

  void _logout() async {
    await _supabase.auth.signOut();
    if (mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFFBF360C),
        title: const Text('PQR Cooperative – Manager',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: _loadData),
          IconButton(
              icon: const Icon(Icons.logout, color: Colors.white),
              onPressed: _logout,
              tooltip: 'Logout'),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFBF360C)))
          : Column(
              children: [
                _buildStatsRow(),
                _buildNavTabs(),
                Expanded(child: _buildTabContent()),
              ],
            ),
    );
  }

  Widget _buildStatsRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFBF360C), Color(0xFFEF6C00)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Row(
        children: [
          _statCard('Members', _totalMembers.toString(), Icons.people_outline,
              Colors.white),
          _statCard('Active Loans', _activeLoans.toString(),
              Icons.credit_card_outlined, Colors.greenAccent),
          _statCard('Pending', _pendingLoans.toString(),
              Icons.pending_actions_outlined, Colors.yellowAccent),
          _statCard('Reports', _unreadReports.toString(), Icons.mail_outline,
              Colors.lightBlueAccent),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(height: 4),
            Text(value,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
            Text(label,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.85), fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Widget _buildNavTabs() {
    final tabs = [
      {'icon': Icons.summarize_outlined, 'label': 'Reports'},
      {'icon': Icons.account_balance_outlined, 'label': 'Loans'},
      {'icon': Icons.manage_accounts_outlined, 'label': 'Customers'},
    ];
    return Container(
      color: Colors.white,
      child: Row(
        children: List.generate(tabs.length, (i) {
          final selected = _selectedIndex == i;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedIndex = i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: selected
                          ? const Color(0xFFBF360C)
                          : Colors.transparent,
                      width: 3,
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    Icon(tabs[i]['icon'] as IconData,
                        color: selected ? const Color(0xFFBF360C) : Colors.grey,
                        size: 22),
                    const SizedBox(height: 4),
                    Text(
                      tabs[i]['label'] as String,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight:
                            selected ? FontWeight.bold : FontWeight.normal,
                        color: selected ? const Color(0xFFBF360C) : Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_selectedIndex) {
      case 0:
        return _buildReports();
      case 1:
        return _buildLoans();
      case 2:
        return _buildCustomers();
      default:
        return const SizedBox();
    }
  }

  Widget _buildReports() {
    if (_reports.isEmpty) {
      return _emptyState(
          Icons.inbox_outlined, 'No reports', 'No reports submitted yet.');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _reports.length,
      itemBuilder: (context, i) {
        final r = _reports[i];
        final isNew = r['status'] == 'submitted';
        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ExpansionTile(
            leading: CircleAvatar(
              backgroundColor:
                  isNew ? Colors.orange.shade50 : Colors.grey.shade100,
              child: Icon(
                isNew
                    ? Icons.mark_email_unread_outlined
                    : Icons.mark_email_read_outlined,
                color: isNew ? Colors.orange : Colors.grey,
                size: 20,
              ),
            ),
            title: Text(
              r['title'] ?? 'Untitled Report',
              style: TextStyle(
                fontWeight: isNew ? FontWeight.bold : FontWeight.w500,
                fontSize: 14,
              ),
            ),
            subtitle: Text(_formatDate(r['created_at']),
                style: const TextStyle(fontSize: 12)),
            trailing: isNew
                ? Chip(
                    label: const Text('New',
                        style: TextStyle(fontSize: 10, color: Colors.white)),
                    backgroundColor: Colors.orange,
                    padding: EdgeInsets.zero,
                  )
                : const Chip(
                    label: Text('Read', style: TextStyle(fontSize: 10)),
                    backgroundColor: Colors.black12,
                    padding: EdgeInsets.zero,
                  ),
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r['content'] ?? 'No content.',
                        style: const TextStyle(fontSize: 13)),
                    const SizedBox(height: 12),
                    if (isNew)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          icon: const Icon(Icons.done_all, size: 16),
                          label: const Text('Mark as Read'),
                          onPressed: () => _markReportRead(r['id']),
                          style: TextButton.styleFrom(
                              foregroundColor: const Color(0xFFBF360C)),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLoans() {
    if (_loans.isEmpty) {
      return _emptyState(
          Icons.credit_card_off_outlined, 'No loans', 'No loan records found.');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _loans.length,
      itemBuilder: (context, i) {
        final loan = _loans[i];
        final status = loan['status'] ?? 'unknown';
        final memberName = loan['members']?['full_name'] ?? 'Unknown';

        Color statusColor;
        switch (status) {
          case 'active':
            statusColor = Colors.green;
            break;
          case 'pending':
            statusColor = Colors.orange;
            break;
          case 'completed':
            statusColor = Colors.blue;
            break;
          default:
            statusColor = Colors.grey;
        }

        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(memberName,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 15),
                          overflow: TextOverflow.ellipsis),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: statusColor),
                      ),
                      child: Text(status.toUpperCase(),
                          style: TextStyle(
                              color: statusColor,
                              fontSize: 11,
                              fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                const Divider(height: 12),
                Row(
                  children: [
                    _loanDetail('Amount',
                        '₱${(loan['amount'] ?? 0.0).toStringAsFixed(2)}'),
                    const SizedBox(width: 20),
                    _loanDetail('Balance Due',
                        '₱${(loan['balance_due'] ?? 0.0).toStringAsFixed(2)}'),
                    const SizedBox(width: 20),
                    _loanDetail('Date', _formatDate(loan['created_at'])),
                  ],
                ),
                if (status == 'pending') ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.close, size: 16),
                          label: const Text('Reject'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.red,
                            side: const BorderSide(color: Colors.red),
                          ),
                          onPressed: () =>
                              _updateLoanStatus(loan['id'], 'rejected'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.check, size: 16),
                          label: const Text('Approve'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: () =>
                              _updateLoanStatus(loan['id'], 'active'),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _loanDetail(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
        Text(value,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _buildCustomers() {
    if (_members.isEmpty) {
      return _emptyState(
          Icons.people_outline, 'No customers', 'No member records found.');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _members.length,
      itemBuilder: (context, i) {
        final m = _members[i];
        final email = m['users']?['email'] ?? '-';
        final balance = (m['balance'] as num? ?? 0.0).toDouble();
        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: CircleAvatar(
              backgroundColor: const Color(0xFFBF360C).withOpacity(0.12),
              child: Text(
                (m['full_name'] ?? 'M')[0].toUpperCase(),
                style: const TextStyle(
                    color: Color(0xFFBF360C), fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(m['full_name'] ?? 'Unknown',
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(email, style: const TextStyle(fontSize: 12)),
                Text('Joined: ${_formatDate(m['created_at'])}',
                    style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text('Balance',
                    style: TextStyle(fontSize: 11, color: Colors.grey)),
                Text('₱${balance.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: Color(0xFFBF360C))),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _emptyState(IconData icon, String title, String subtitle) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 64, color: Colors.grey.shade300),
        const SizedBox(height: 16),
        Text(title,
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey)),
        const SizedBox(height: 6),
        Text(subtitle,
            style: const TextStyle(fontSize: 13, color: Colors.grey)),
      ]),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return '-';
    try {
      final d = DateTime.parse(date.toString()).toLocal();
      return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    } catch (_) {
      return date.toString();
    }
  }
}
