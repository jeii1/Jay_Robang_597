import 'package:flutter/material.dart';
import 'package:pqr_cooperative/App/go_router.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:pqr_cooperative/App/app_theme.dart';
import 'package:pqr_cooperative/App/auth_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 
      'https://vlkxaperxqrqmfxahkoy.supabase.co',
     anonKey: 
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZsa3hhcGVyeHFycW1meGFoa295Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3OTE5OTExNiwiZXhwIjoyMDk0Nzc1MTE2fQ._8Wnu-gIEuJ-ol1-J5i1md_aOoWdIziwQDVuyxD0DAw', 
  );

  runApp(const PQRCooperativeApp());
}

class PQRCooperativeApp extends StatelessWidget {
  const PQRCooperativeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AuthProvider(),
      child: Consumer<AuthProvider>(
        builder: (context, authProvider, _) {
          return MaterialApp.router(
            title: 'PQR Cooperative',
            theme: AppTheme.lightTheme,
            routerConfig: AppRouter.router(authProvider),
            debugShowCheckedModeBanner: false,
          );
        },
      ),
    );
  }
}