class User {
  final int id;
  final String name;
  final String email;

  User({required this.id, required this.name, required this.email});

  //convert json
  factory User.fromjson(Map<String, dynamic> json) {
    return User(id: json['id'], name: json['name'], email: json['email']);
  }

  //convert user object to json
  Map<String, dynamic> toJson(){
    return{
      'id': id,
      'name': name,
      'email': email
    };
  } 
}
